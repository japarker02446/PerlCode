package Bio::JParker::DnaThermodynamics;

# Copyright 2009, Jefferson A. Parker, Febit Inc.
# ALL RIGHTS RESERVED

use 5.008008;
use strict;
use warnings;

our $VERSION = '1.2';

# Suppress 'Use of uninitialized value' warning messages.
no warnings 'uninitialized';

# This module contains a collection of subroutines that are shared by the 
# Bio::JParker collection of PERL DNA thermodynamic and secondary 
# structure prediction programs.

=head1 NAME

Bio::JParker::DnaThermodynamics

=head1 SYNOPSIS

use Bio::JParker::DnaThermodynamics;

=head1 DESCRIPTION

Perl extension for calculation of DNA thermodynamic parameters of 
structural components (helices, hairpin loops, bulge loops and 
internal loops) based on the Nearest Neighbor Model and UNAFold.

Additional functionality for the component DNA base pair stacking 
thermodynamic parameters from the Nearest Neighbor Model are provided.

C<Bio::JParker::DnaThermodynamics> B<IS NOT> part of the BioPerl
library.  I have written it to install in the same lib directory
because it is a biological module.

=head1 Functions

=cut

########### THERMODYNAMIC CONSTANT HASHES ########################
# The following hashes of arrays are constants of thermodynamic
# parameters (free energy, entropy, enthalpy) for loops and 
# DNA helix doublets as described in SantaLucia and Hicks, 
# Annu Rev Biophys Biomol Struct 33, 415-440 (2004) or derived 
# from Zuker, Nucleic Acids Res. 31 (13), 3406-15, (2003)
# 
# Loop hashes are for the sequence of the loop and the closing
# base pair of the loop.
# 
# The DNA helix doublet hash keys are the stacked dinucleotide base
# pairs of $seqString1 and $seqString2 oriented 5'->3' and 3'->5'.
# (The sequence 5'-CG-3' would have the matched partner 3'-CG-5',
# so the parameters for this pair would be retrieved as
# @{$dnaThermoHash{CG}{CG}}


# Hash of arrays of free energy (deltaG) and enthalpy (deltaH) of 
# stable GNA triplet hairpin loops.
# %{sequence} => [dG][[dH]
our %tripletLoopEnergyHash = (
	'AGAAT' => [-1.5, -1.5 ],
	'AGCAT' => [-1.5, -1.5 ],
	'AGGAT' => [-1.5, -1.5 ],
	'AGTAT' => [-1.5, -1.5 ],
	'CGAAG' => [-2.0, -2.0 ],
	'CGCAG' => [-2.0, -2.0 ],
	'CGGAG' => [-2.0, -2.0 ],
	'CGTAG' => [-2.0, -2.0 ],
	'GGAAC' => [-2.0, -2.0 ],
	'GGCAC' => [-2.0, -2.0 ],
	'GGGAC' => [-2.0, -2.0 ],
	'GGTAC' => [-2.0, -2.0 ],
	'TGAAA' => [-1.5, -1.5 ],
	'TGCAA' => [-1.5, -1.5 ],
	'TGGAA' => [-1.5, -1.5 ],
	'TGTAA' => [-1.5, -1.5 ],
);

# Hash of arrays of free energy (deltaG) and enthalpy (deltaH) of 
# more or less stable than normal sequence dependent loops.
# %{sequence} => [dG][[dH]
our %tetraLoopEnergyHash = (
	'AAAAAT' => [0.7, 0.5 ],
	'AAAACT' => [0.2, 0.7 ],
	'AAACAT' => [0.5, 1 ],
	'ACTTGT' => [-1.3, 0 ],
	'AGAAAT' => [-1.6, -1.1 ],
	'AGAGAT' => [-1.6, -1.1 ],
	'AGATAT' => [-2, -1.5 ],
	'AGCAAT' => [-2.1, -1.6 ],
	'AGCGAT' => [-1.6, -1.1 ],
	'AGCTTT' => [-0.3, 0.2 ],
	'AGGAAT' => [-1.6, -1.1 ],
	'AGGGAT' => [-1.6, -1.1 ],
	'AGGGGT' => [0.3, 0.5 ],
	'AGTAAT' => [-2.1, -1.6 ],
	'AGTGAT' => [-1.6, -1.1 ],
	'AGTTCT' => [0.3, 0.8 ],
	'ATTCGT' => [-0.7, -0.2 ],
	'ATTTGT' => [-0.5, 0 ],
	'ATTTTT' => [-1, -0.5 ],
	'CAAAAG' => [0.9, 0.5 ],
	'CAAACG' => [0.7, 0.7 ],
	'CAACAG' => [1, 1 ],
	'CAACCG' => [0, 0 ],
	'CCTTGG' => [-0.8, 0 ],
	'CGAAAG' => [-1.1, -1.1 ],
	'CGAGAG' => [-1.1, -1.1 ],
	'CGATAG' => [-1.5, -1.5 ],
	'CGCAAG' => [-1.6, -1.6 ],
	'CGCGAG' => [-1.1, -1.1 ],
	'CGCTTG' => [0.2, 0.2 ],
	'CGGAAG' => [-1.1, -1.1 ],
	'CGGGAG' => [-1, -1 ],
	'CGGGGG' => [0.8, 0.5 ],
	'CGTAAG' => [-1.6, -1.6 ],
	'CGTGAG' => [-1.1, -1.1 ],
	'CGTTCG' => [0.8, 0.8 ],
	'CTTCGG' => [-0.2, -0.2 ],
	'CTTTGG' => [0, 0 ],
	'CTTTTG' => [-0.5, -0.5 ],
	'GAAAAC' => [1.5, 0.5 ],
	'GAAACC' => [0.7, 0.7 ],
	'GAACAC' => [1, 1 ],
	'GCTTGC' => [-0.8, 0 ],
	'GGAAAC' => [-1.1, -1.1 ],
	'GGAGAC' => [-1.1, -1.1 ],
	'GGATAC' => [-1.6, -1.6 ],
	'GGCAAC' => [-1.6, -1.6 ],
	'GGCGAC' => [-1.1, -1.1 ],
	'GGCTTC' => [0.2, 0.2 ],
	'GGGAAC' => [-1.1, -1.1 ],
	'GGGGAC' => [-1.1, -1.1 ],
	'GGGGGC' => [0.8, 0.5 ],
	'GGTAAC' => [-1.6, -1.6 ],
	'GGTGAC' => [-1.1, -1.1 ],
	'GGTTCC' => [0.8, 0.8 ],
	'GTTCGC' => [-0.2, -0.2 ],
	'GTTTGC' => [0, 0 ],
	'GTTTTC' => [-0.5, -0.5 ],
	'GAAAAT' => [1.5, 0.5 ],
	'GAAACT' => [1, 1 ],
	'GAACAT' => [1, 1 ],
	'GCTTGT' => [-0.5, 0 ],
	'GGAAAT' => [-1.1, -1.1 ],
	'GGAGAT' => [-1.1, -1.1 ],
	'GGATAT' => [-1.6, -1.6 ],
	'GGCAAT' => [-1.6, -1.6 ],
	'GGCGAT' => [-1.1, -1.1 ],
	'GGCTTT' => [-0.1, -0.1 ],
	'GGGAAT' => [-1.1, -1.1 ],
	'GGGGAT' => [-1.1, -1.1 ],
	'GGGGGT' => [0.8, 0.5 ],
	'GGTAAT' => [-1.6, -1.6 ],
	'GGTGAT' => [-1.1, -1.1 ],
	'GTATAT' => [-0.5, -0.5 ],
	'GTTCGT' => [-0.4, -0.4 ],
	'GTTTGT' => [-0.4, -0.4 ],
	'GTTTTT' => [-0.5, -0.5 ],
	'TAAAAA' => [0.4, 0.5 ],
	'TAAACA' => [0.2, 0.7 ],
	'TAACAA' => [0.5, 1 ],
	'TCTTGA' => [-1.3, 0 ],
	'TGAAAA' => [-1.6, -1.1 ],
	'TGAGAA' => [-1.6, -1.1 ],
	'TGATAA' => [-2.1, -1.6 ],
	'TGCAAA' => [-2.1, -1.6 ],
	'TGCGAA' => [-1.6, -1.1 ],
	'TGCTTA' => [-0.3, 0.2 ],
	'TGGAAA' => [-1.6, -1.1 ],
	'TGGGAA' => [-1.6, -1.1 ],
	'TGGGGA' => [0.3, 0.5 ],
	'TGTAAA' => [-2.1, -1.6 ],
	'TGTGAA' => [-1.6, -1.1 ],
	'TGTTCA' => [0.3, 0.8 ],
	'TTTCGA' => [-0.7, -0.2 ],
	'TTTTGA' => [-0.5, 0 ],
	'TTTTTA' => [-1, -0.5 ],
	'TAAAAG' => [1, 0.5 ],
	'TAAACG' => [0.5, 1 ],
	'TAACAG' => [0.5, 1 ],
	'TCTTGG' => [-1, 0 ],
	'TGAAAG' => [-1.5, -1 ],
	'TGAGAG' => [-1.5, -1 ],
	'TGATAG' => [-2, -1.5 ],
	'TGCAAG' => [-2, -1.5 ],
	'TGCGAG' => [-1.5, -1 ],
	'TGCTTG' => [-0.6, -0.1 ],
	'TGGAAG' => [-1.5, -1 ],
	'TGGGAG' => [-1.5, -1 ],
	'TGGGGG' => [0.3, 0.5 ],
	'TGTAAG' => [-2, -1.5 ],
	'TGTGAG' => [-1.5, -1 ],
	'TTTCGG' => [-0.9, -0.4 ],
	'TTTTAG' => [-1.5, -1 ],
	'TTTTGG' => [-0.9, -0.4 ],
	'TTTTTG' => [-1, -0.5 ],
);

# Dangling terminal helix doublets.
our %danglingThermoHash = (
	'-A' => {
		'AT' => [ -0.7, -0.8, -0.48],
		'CT' => [ 4.4, 14.9, -0.19],
		'GT' => [ -1.6, -3.6, -0.5],
		'TT' => [ 2.9, 10.4, -0.29],
	},
	
	'-C' => {
		'AG' => [ -2.1, -3.9, -0.92],
		'CG' => [ -0.2, -0.1, -0.23],
		'GG' => [ -3.9, -11.2, -0.44],
		'TG' => [ -4.4, -13.1, -0.35],
	},
	
	'-G' => {
		'AC' => [ -5.9, -16.5, -0.82],
		'CC' => [ -2.6, -7.4, -0.31],
		'GC' => [ -3.2, -10.4, -0.01],
		'TC' => [ -5.2, -15, -0.52],
	},
	
	'-T' => {
		'AA' => [ -0.5, -1.1, -0.12],
		'CA' => [ 4.7, 14.2, 0.28],
		'GA' => [ -4.1, -13.1, -0.01],
		'TA' => [ -3.8, -12.6, 0.13],
	},
	
	'AT' => {'-A' => [ -2.9, -7.6, -0.5],},
	'CT' => {'-A' => [ -4.1, -13, -0.02],},
	'GT' => {'-A' => [ -4.2, -15, 0.48],},
	'TT' => {'-A' => [ -0.2, -0.5, -0.1],},
	'AG' => {'-C' => [ -3.7, -10, -0.58],},
	'CG' => {'-C' => [ -4, -11.9, -0.34],},
	'GG' => {'-C' => [ -3.9, -10.9, -0.56],},
	'TG' => {'-C' => [ -4.9, -13.8, -0.61],},
	'AC' => {'-G' => [ -6.3, -17.1, -0.96],},
	'CC' => {'-G' => [ -4.4, -12.6, -0.52],},
	'GC' => {'-G' => [ -5.1, -14, -0.72],},
	'TC' => {'-G' => [ -4, -10.9, -0.58],},
	'AA' => {'-T' => [ 0.2, 2.3, -0.51],},
	'CA' => {'-T' => [ 0.6, 3.3, -0.42],},
	'GA' => {'-T' => [ -1.1, -1.6, -0.62],},
	'TA' => {'-T' => [ -6.9, -20, -0.71],},
);

# Helix terminal doublets.
our %endThermoHash = (
	'AA' => {
		'AT' => [ -0.5, 1.58, -0.99],
		'CT' => [ 4.6, 17.09, -0.7],
		'GT' => [ -1.4, -1.26, -1.01],
		'TA' => [ -3.2, -8.06, -0.7],
		'TC' => [ -0.9, -1.94, -0.3],
		'TG' => [ -2.3, -5.8, -0.5],
		'TT' => [ -7.6, -21.3, -1],
	},
	
	'AC' => {
		'AG' => [ -8.4, -21.02, -1.88],
		'CG' => [ -6.5, -17.12, -1.19],
		'GG' => [ -10.2, -28.37, -1.4],
		'TA' => [ -2.4, -5.16, -0.8],
		'TC' => [ -1.4, -2.91, -0.5],
		'TG' => [ -8.4, -22.4, -1.44],
		'TT' => [ -2.4, -5.49, -0.7],
	},
	
	'AG' => {
		'AC' => [ -9.6, -26.44, -1.4],
		'CC' => [ -6.3, -17.44, -0.89],
		'GC' => [ -6.9, -20.34, -0.59],
		'TA' => [ -4, -9.67, -1],
		'TC' => [ -7.8, -21, -1.28],
		'TG' => [ -5.3, -13.86, -1],
		'TT' => [ -3.7, -9.35, -0.8],
	},
	
	'AT' => {
		'AA' => [ -3.4, -8.96, -0.62],
		'CA' => [ -2.9, -7.74, -0.5],
		'GA' => [ -7, -20.93, -0.51],
		'TA' => [ -7.2, -20.4, -0.88],
		'TC' => [ -1.4, -3.55, -0.3],
		'TG' => [ -3.7, -10, -0.6],
		'TT' => [ -2.3, -6.45, -0.3],
	},
	
	'CA' => {
		'AT' => [ -0.1, 2.58, -0.9],
		'CT' => [ 5, 18.09, -0.61],
		'GA' => [ -3.2, -8.06, -0.7],
		'GC' => [ -0.9, -1.94, -0.3],
		'GG' => [ -2.3, -5.8, -0.5],
		'GT' => [ -8.5, -22.7, -1.45],
		'TT' => [ 3.5, 13.58, -0.71],
	},
	
	'CC' => {
		'AG' => [ -6.5, -16.32, -1.44],
		'CG' => [ -4.6, -12.41, -0.75],
		'GA' => [ -2.4, -5.16, -0.8],
		'GC' => [ -1.4, -2.91, -0.5],
		'GG' => [ -8, -19.9, -1.84],
		'GT' => [ -2.4, -5.49, -0.7],
		'TG' => [ -8.8, -25.57, -0.87],
	},
	
	'CG' => {
		'AC' => [ -9.9, -28.18, -1.16],
		'CC' => [ -6.6, -19.18, -0.65],
		'GA' => [ -4, -9.67, -1],
		'GC' => [ -10.6, -27.2, -2.17],
		'GG' => [ -5.3, -13.86, -1],
		'GT' => [ -3.7, -9.35, -0.8],
		'TC' => [ -9.2, -26.89, -0.86],
	},
	
	'CT' => {
		'AA' => [ -4.6, -14.38, -0.14],
		'CA' => [ -4.1, -13.15, -0.02],
		'GA' => [ -7.8, -21, -1.28],
		'GC' => [ -1.4, -3.55, -0.3],
		'GG' => [ -3.7, -10, -0.6],
		'GT' => [ -2.3, -6.45, -0.3],
		'TA' => [ -4.1, -13.15, -0.02],
	},
	
	'GA' => {
		'AT' => [ -1.8, -2.25, -1.1],
		'CA' => [ -3.2, -8.06, -0.7],
		'CC' => [ -0.9, -1.94, -0.3],
		'CG' => [ -2.3, -5.8, -0.5],
		'CT' => [ -8.2, -22.2, -1.3],
		'GT' => [ -2.7, -5.09, -1.12],
		'TT' => [ 1.8, 8.74, -0.91],
	},
	
	'GC' => {
		'AG' => [ -7.2, -17.93, -1.64],
		'CA' => [ -2.4, -5.16, -0.8],
		'CC' => [ -1.4, -2.91, -0.5],
		'CG' => [ -9.8, -24.4, -2.24],
		'CT' => [ -2.4, -5.49, -0.7],
		'GG' => [ -9, -25.28, -1.16],
		'TG' => [ -9.5, -27.18, -1.07],
	},
	
	'GG' => {
		'AC' => [ -9.8, -27.15, -1.38],
		'CA' => [ -4, -9.67, -1],
		'CC' => [ -8, -19.9, -1.84],
		'CG' => [ -5.3, -13.86, -1],
		'CT' => [ -3.7, -9.35, -0.8],
		'GC' => [ -7.1, -21.05, -0.57],
		'TC' => [ -9.1, -25.86, -1.08],
	},
	
	'GT' => {
		'AA' => [ -0.5, -1.23, -0.12],
		'CA' => [ -8.4, -22.4, -1.44],
		'CC' => [ -1.4, -3.55, -0.3],
		'CG' => [ -3.7, -10, -0.6],
		'CT' => [ -2.3, -6.45, -0.3],
		'GA' => [ -4.1, -13.19, -0.01],
		'TA' => [ 0, 0, 0],
	},
	
	'TA' => {
		'AA' => [ -3.2, -8.06, -0.7],
		'AC' => [ -0.9, -1.94, -0.3],
		'AG' => [ -2.3, -5.8, -0.5],
		'AT' => [ -7.2, -21.3, -0.58],
		'CT' => [ -2.5, -5.16, -0.9],
		'GT' => [ -8.5, -23.5, -1.21],
		'TT' => [ -4, -9.67, -1],
	},'TC' => {
		'AA' => [ -2.4, -5.16, -0.8],
		'AC' => [ -1.4, -2.91, -0.5],
		'AG' => [ -8.2, -22.2, -1.3],
		'AT' => [ -2.4, -5.49, -0.7],
		'CG' => [ -4.2, -10.93, -0.81],
		'GG' => [ -7.9, -22.18, -1.02],
		'TG' => [ -8.4, -24.09, -0.93],
	},'TG' => {
		'AA' => [ -4, -9.67, -1],
		'AC' => [ -8.5, -22.7, -1.45],
		'AG' => [ -5.3, -13.86, -1],
		'AT' => [ -3.7, -9.35, -0.8],
		'CC' => [ -7.5, -21.21, -0.92],
		'GC' => [ -8.1, -24.11, -0.62],
		'TC' => [ -10.1, -28.92, -1.13],
	},'TT' => {
		'AA' => [ -7.6, -21.3, -1],
		'AC' => [ -1.4, -3.55, -0.3],
		'AG' => [ -3.7, -10, -0.6],
		'AT' => [ -2.3, -6.45, -0.3],
		'CA' => [ -0.2, -0.32, -0.1],
		'GA' => [ -4.3, -13.51, -0.11],
		'TA' => [ -1, -0.32, -0.1],
	},
);

# Helix internal doublets.
our %midThermoHash = (
	'AA' => {
		'AT' => [ 4.7, 12.9, 0.69],
		'CT' => [ 7.6, 20.2, 1.33],
		'GT' => [ 3, 7.4, 0.74],
		'TA' => [ 1.2, 1.7, 0.61],
		'TC' => [ 2.3, 4.6, 0.88],
		'TG' => [ -0.6, -2.3, 0.14],
		'TT' => [ -7.6, -21.3, -1],
	},
	
	'AC' => {
		'AG' => [ -2.9, -9.8, 0.17],
		'CG' => [ -0.7, -3.8, 0.47],
		'GG' => [ 0.5, 3.2, -0.52],
		'TA' => [ 5.3, 14.6, 0.77],
		'TC' => [ 0, -4.4, 1.33],
		'TG' => [ -8.4, -22.4, -1.44],
		'TT' => [ 0.7, 0.2, 0.64],
	},
	
	'AG' => {
		'AC' => [ -0.9, -4.2, 0.43],
		'CC' => [ 0.6, -0.6, 0.79],
		'GC' => [ -4, -13.2, 0.11],
		'TA' => [ -0.7, -2.3, 0.02],
		'TC' => [ -7.8, -21, -1.28],
		'TG' => [ -3.1, -9.5, -0.13],
		'TT' => [ 1, 0.9, 0.71],
	},
	
	'AT' => {
		'AA' => [ 1.2, 1.7, 0.61],
		'CA' => [ 5.3, 14.6, 0.77],
		'GA' => [ -0.7, -2.3, 0.02],
		'TA' => [ -7.2, -20.4, -0.88],
		'TC' => [ -1.2, -6.2, 0.73],
		'TG' => [ -2.5, -8.3, 0.07],
		'TT' => [ -2.7, -10.8, 0.69],
	},
	
	'CA' => {
		'AT' => [ 3.4, 8, 0.92],
		'CT' => [ 6.1, 16.4, 1.05],
		'GA' => [ -0.9, -4.2, 0.43],
		'GC' => [ 1.9, 3.7, 0.75],
		'GG' => [ -0.7, -2.3, 0.03],
		'GT' => [ -8.5, -22.7, -1.45],
		'TT' => [ 1, 0.7, 0.75],
	},
	
	'CC' => {
		'AG' => [ 5.2, 14.2, 0.81],
		'CG' => [ 3.6, 8.9, 0.79],
		'GA' => [ 0.6, -0.6, 0.79],
		'GC' => [ -1.5, -7.2, 0.7],
		'GG' => [ -8, -19.9, -1.84],
		'GT' => [ -0.8, -4.5, 0.62],
		'TG' => [ 5.2, 13.5, 0.98],
	},
	
	'CG' => {
		'AC' => [ 1.9, 3.7, 0.75],
		'CC' => [ -1.5, -7.2, 0.7],
		'GA' => [ -4, -13.2, 0.11],
		'GC' => [ -10.6, -27.2, -2.17],
		'GG' => [ -4.9, -15.3, -0.11],
		'GT' => [ -4.1, -11.7, -0.47],
		'TC' => [ -1.5, -6.1, 0.4],
	},
	
	'CT' => {
		'AA' => [ 2.3, 4.6, 0.88],
		'CA' => [ 0, -4.4, 1.33],
		'GA' => [ -7.8, -21, -1.28],
		'GC' => [ -1.5, -6.1, 0.4],
		'GG' => [ -2.8, -8, -0.32],
		'GT' => [ -5, -15.8, -0.12],
		'TA' => [ -1.2, -6.2, 0.73],
	},
	
	'GA' => {
		'AT' => [ 0.7, 0.7, 0.42],
		'CA' => [ -2.9, -9.8, 0.17],
		'CC' => [ 5.2, 14.2, 0.81],
		'CG' => [ -0.6, -1, -0.25],
		'CT' => [ -8.2, -22.2, -1.3],
		'GT' => [ 1.6, 3.6, 0.44],
		'TT' => [ -1.3, -5.3, 0.34],
	},
	
	'GC' => {
		'AG' => [ -0.6, -1, -0.25],
		'CA' => [ -0.7, -3.8, 0.47],
		'CC' => [ 3.6, 8.9, 0.79],
		'CG' => [ -9.8, -24.4, -2.24],
		'CT' => [ 2.3, 5.4, 0.62],
		'GG' => [ -6, -15.8, -1.11],
		'TG' => [ -4.4, -12.3, -0.59],
	},
	
	'GG' => {
		'AC' => [ -0.7, -2.3, 0.03],
		'CA' => [ 0.5, 3.2, -0.52],
		'CC' => [ -8, -19.9, -1.84],
		'CG' => [ -6, -15.8, -1.11],
		'CT' => [ 3.3, 10.4, 0.08],
		'GC' => [ -4.9, -15.3, -0.11],
		'TC' => [ -2.8, -8, -0.32],
	},
	
	'GT' => {
		'AA' => [ -0.6, -2.3, 0.14],
		'CA' => [ -8.4, -22.4, -1.44],
		'CC' => [ 5.2, 13.5, 0.98],
		'CG' => [ -4.4, -12.3, -0.59],
		'CT' => [ -2.2, -8.4, 0.45],
		'GA' => [ -3.1, -9.5, -0.13],
		'TA' => [ -2.5, -8.3, 0.07],
	},
	
	'TA' => {
		'AA' => [ 4.7, 12.9, 0.69],
		'AC' => [ 3.4, 8, 0.92],
		'AG' => [ 0.7, 0.7, 0.42],
		'AT' => [ -7.2, -21.3, -0.58],
		'CT' => [ 1.2, 0.7, 0.97],
		'GT' => [ -0.1, -1.7, 0.43],
		'TT' => [ 0.2, -1.5, 0.68],
	},
	
	'TC' => {
		'AA' => [ 7.6, 20.2, 1.33],
		'AC' => [ 6.1, 16.4, 1.05],
		'AG' => [ -8.2, -22.2, -1.3],
		'AT' => [ 1.2, 0.7, 0.97],
		'CG' => [ 2.3, 5.4, 0.62],
		'GG' => [ 3.3, 10.4, 0.08],
		'TG' => [ -2.2, -8.4, 0.45],
	},
	
	'TG' => {
		'AA' => [ 3, 7.4, 0.74],
		'AC' => [ -8.5, -22.7, -1.45],
		'AG' => [ 1.6, 3.6, 0.44],
		'AT' => [ -0.1, -1.7, 0.43],
		'CC' => [ -0.8, -4.5, 0.62],
		'GC' => [ -4.1, -11.7, -0.47],
		'TC' => [ -5, -15.8, -0.12],
	},
	
	'TT' => {
		'AA' => [ -7.6, -21.3, -1],
		'AC' => [ 1, 0.7, 0.75],
		'AG' => [ -1.3, -5.3, 0.34],
		'AT' => [ 0.2, -1.5, 0.68],
		'CA' => [ 0.7, 0.2, 0.64],
		'GA' => [ 1, 0.9, 0.71],
		'TA' => [ -2.7, -10.8, 0.69],
	},
);

################ DNA THERMODYNAMIC PARAMETER SUBROUTINES ###############
# The following subroutines calculate different levels of thermodynamic
# parameters for two DNA sequences:
# 
# sumDoubletThermo: Return thermodynamic parameters for two sequences
# 					with full length alignment at all positions.
# calcAllThermo:	Return thermodynamic parameters for two sequences
#					at all stable, non-nested, alignments.
# calcMaxThermo:	Return thermodynamic parameters for the most stable
# 					alignment of two sequences.
# calcDnaTm:		Return the melting temperature for two sequences
# 					with full length alignment at all positions.
# calcMaxTm:		Return the melting temperature and free energy for
# 					the most stable alignment of two sequences.

sub sumDoubletThermo {

=head2 sumDoubletThermo

=over

=item Usage:

($dH, $dS, $dG) = sumDoubletThermo($dnaSeq1, $dnaSeq2);

=item Function:

Calculate the free energy of duplex hybridization for the DNA sequences
$seqString1 and $seqString2 using the Nearest Neighbor Model of DNA base
pair stacking described in SantaLucia and Hicks, Annu Rev Biophys 
Biomol Struct 33, 415-440 (2004).

This subroutine assumes that both sequences hybridize across their 
full length.  The two DNA strings must be the same length.  Any 
helix disruption event (internal or terminal double mismatch) will 
cause the calculation to abort and return a null list of values.

=item Arguments:

Two DNA sequence strings in 5' -> 3' orientation.

=item Returns:

Thermodynamic parameters of the stable helix: standard enthalpy
(delta H) and entropy(delta S) and free energy (delta G) at 37
degrees C and 1M NaCl upon success or an empty list upon failure.

=back

=cut
	
	my $seqString1 = uc(shift);
	my $seqString2 = reverse(uc(shift));
	
	#print "Received: $seqString1\t$seqString2\n";
	
	# Initialize local variables.  We do not use the standard duplex 
	# initiation thermodynamic parameters because accurate terminal base 
	# pair parameters are available.
	my $sumH = 0;
	my $sumS = 0;
	my $sumG = 0;
	
	# Test input parameter validity.
	# We must have two sequences of the same length.
	unless ($seqString2){
		warn "ERROR: Bio::JParker::DnaThermodynamics::sumDoubletThermo\n"
		. " - must have TWO DNA sequences as input.\n";
		return ();
	}
	
	unless(length($seqString1) == length($seqString2)){
		warn "ERROR: Bio::JParker::DnaThermodynamics::sumDoubletThermo\n"
			. "sumDoubletThermo requires two DNA sequences of equal length:"
			. "$seqString1\t$seqString2\.\n";
		return ();
	}
	
	# Sum the thermodynamic parameters of each doublet of base pairs
	# until the helix terminates (double mismatch) or their end.
	for my $i (0 .. (length($seqString1) - 2)){
		
		# If we are at the first base pair, test for helix initiation.
		if($i == 0){
			($sumH, $sumS, $sumG) = getEndThermo(
										substr($seqString1, $i, 2),
										substr($seqString2, $i, 2)
									);
			if ($sumG){
	#			print "$i\t", substr($seqString1, $i, 2),"\t",
	#				substr($seqString2, $i, 2),"\t$sumG\tDuplex initiation\n";
			}
			else{
	#			print "$i\t", substr($seqString1, $i, 2),"\t",
	#				substr($seqString2, $i, 2),"\t$sumG\tFailed duplex initiation\n";
				return();
			}
		}
		
		# If we get to the last base pair, apply the terminal
		# duplex energy.  If there is no terminal duplex energy
		# the helix failed at the last doublet.
		elsif($i == (length($seqString1) - 2)){
			my ($dH1, $dS1, $dG1) = getEndThermo(
										substr($seqString1, $i, 2),
										substr($seqString2, $i, 2)
									);
			if($dG1){
				$sumH += $dH1;
				$sumS += $dS1;
				$sumG += $dG1;
	#			print "$i\t", substr($seqString1, $i, 2),"\t",
	#				substr($seqString2, $i, 2),"\t$dG1\tDuplex termination, end of sequence\n";
				last;
			}
			else{
	#			print "$i\t", substr($seqString1, $i, 2),"\t",
	#				substr($seqString2, $i, 2),"\t\tDuplex termination, double mismatch\n";
				return();
			}
		}
		
		# Calculate the energy of the intermediate base pairs.
		# Intermediate free energies can be stabilizing or 
		# destabilizing for match or single base mismatch base
		# pairs, respectively.  Double mismatches will not 
		# return a value.
		else{
			my ($dH2, $dS2, $dG2) = getMidThermo(
										substr($seqString1, $i, 2),
										substr($seqString2, $i, 2)
									);
			if($dG2){
				
				# Stabilizing intermediate base pairs will have a negative
				# free energy value.
				if($dG2 < 0){
					$sumH += $dH2;
					$sumS += $dS2;
					$sumG += $dG2;
	#				print "$i\t", substr($seqString1, $i, 2),"\t",
	#					substr($seqString2, $i, 2),"\t$dG2\tDuplex extension, match\n";
				}
				
				# Destabilizing intermediate base pairs will have positive
				# free energy.  A destabilizing intermeadiate base pair may
				# be a single base mismatch or a double base mismatch.  To
				# determine which it is, we must peek at the next doublet
				# $i + 1.  If the $i + 1 doublet has a negative free energy
				# it is stabilizing and the doublet $i is a simply a single
				# base mismatch.  If the $i + 1 doublet is a double mismatch
				# it will not have a free energy and the helix terminates
				# prematurely.
				elsif($dG2 > 0){
					
	#				print "$i\t", substr($seqString1, $i, 2),"\t",
	#					substr($seqString2, $i, 2),"\t$dG2\tWarning, single mismatch\n";
					
					# If the $i + 1 doublet is stabilizing the doublet $i is a
					# single base mismatch, otherwise it is a double mismatch.
					my ($dH3, $dS3, $dG3) = getMidThermo(
												substr($seqString1, $i + 1, 2),
												substr($seqString2, $i + 1, 2)
											);
					if($dG3){
						$sumH += $dH2;
						$sumS += $dS2;
						$sumG += $dG2;
	#					print "$i\t", substr($seqString1, $i, 2),"\t",
	#						substr($seqString2, $i, 2),"\t$dG2\tDuplex extension, single mismatch\n";
					}
					else{
	#					print "$i\t", substr($seqString1, $i, 2),"\t",
	#						substr($seqString2, $i + 1, 2),"\t\tDuplex termination, double mismatch\n";
						return();
					}
				}
			}
			else{
	#			print "$i\t", substr($seqString1, $i, 2),"\t",
	#				substr($seqString2, $i, 2),"\t\tDuplex termination, double mismatch\n";
				return();
			}
		}
	}
	
	# Apply symmetry penalty if the two sequences are identical.
	if($seqString1 eq $seqString2){
		$sumG += 0.43;
		$sumS += -1.4;
	}
	
	return ($sumH, $sumS, $sumG);
}

sub calcAllSelfThermo {

=head2 calcAllSelfThermo

=over

=item Usage: 

@allSelfHelixThermo = calcAllSelfThermo($seqString);

=item Function:

Calculate ALL stable helices a single DNA sequence against itself based
on the Nearest Neighbor Model of DNA Base Stacking.

=item Arguments:

A DNA sequence in 5' -> 3' orientation

=item Returns:

A two dimensional array of helix thermodynamic parameters of the stable
hairpin forming helices.  Each sub-array contains:
[0] = dH, standard enthalpy
[1] = dS, standard entropy
[2] = dG, standard free energy
[3] = index of helix strand 1 start position
[4] = index of helix strand 1 end position
[5] = index of helix strand 2 start position
[6] = index of helix strand 2 end position
[7] = helix length

Standard thermodynamic parameters are calculated at 37 degrees C and 1M NaCl,
helix strand indeces are of the first and last base of each helix strand 
relative to the input sequences.  The helix coordinates include possible 
terminal mismatch bases at both ends.

=back

=cut

	
	my $seqString = shift;
	my $seqLength = length($seqString);
	my @allHelix = ([0, 0, 0, 0, 0, 0]);
	
	# Search for stable helices by "sliding" one copy of the
	# sequence against another copy.  The ends of the helix
	# strands must be ordered:
	# 0 <= startS1 < endS1 < startS2 < endS2 <= length($seqString)
	# 
	# $i = strand1 helix start, start at 0 and go forward
	# $j = strand2 helix start, start at $seqLength and go backward
	for (my $i = 0; $i <= $seqLength - 5; $i ++){
		for (my $j = $seqLength - 2; $j > $i + 3; $j --){
			
			# The helix length $k is at least 2.
			# The helix length is at most:
			# 	strand2 start to the end of the sequence, OR
			# 	strand1 start to strand2 start minus minimum loop
			my $kMax = $seqLength - $j;
			if($kMax > ($j - $i - 3)){$kMax = ($j - $i - 3);}
			
			for (my $k = 2; $k <= $kMax; $k ++){
				my $strand1 = substr($seqString, $i, $k);
				my $strand2 = substr($seqString, $j, $k);
				my ($dH, $dS, $dG) = Bio::JParker::DnaThermodynamics::sumDoubletThermo($strand1, $strand2);
				
				# If the helix is stable
				if($dG < 0){
					my $start1 = $i;
					my $end1 = $i + $k;
					my $start2 = $j;
					my $end2 = $j + $k;
					my $helixLength = $k;
					
					push (@allHelix, [$dH, $dS, $dG, $start1, $end1, $start2, $end2, $helixLength]);
				}
			}
		}
	}
	
	# Remove the empty initializing helix if there are other entries:
	if(scalar(@allHelix) > 1){splice(@allHelix, 0, 1);}
	
	return (@allHelix);
}

sub calcAllThermo {

=head2 calcAllThermo

=over

=item Usage:

@allHelixThermo = calcAllThermo($dnaSeq1, $dnaSeq2);

=item Function:

Calculate ALL stable helices between two DNA sequences based on the Nearest
Neighbor Model of DNA Base Stacking.

=item Arguments:

Two DNA sequences in 5' -> 3' orientation.

=item Returns:

A  two dimensional array of helix thermodynamic parameters of all stable 
helices.  Each sub-array contains:
[0] = dH, standard enthalpy
[1] = dS, standard entropy
[2] = dG, standard free energy
[3] = index of $dnaSeq1 helix start position
[4] = index of $dnaSeq1 helix end position
[5] = index of $dnaSeq2 helix start position
[6] = index of $dnaSeq2 helix end position
[7] = helix length

Standard thermodynamic parameters are calculated at 37 degrees C and 1M NaCl,
helix strand indeces are of the first and last base of each helix strand 
relative to the input sequences.

=back

=cut
	
	my $seqString1 = uc(shift);
	my $seqString2 = uc(shift);
	
	#print "In calcAllThermo\n";
	
	# All stable helices will be stored and returnd in the 
	# two dimensional array @allHelix:
	# [0] = dH
	# [1] = dS
	# [2] = dG
	# [3] = index of strand1 start position
	# [4] = index of strand1 end position
	# [5] = index of strand2 start position
	# [6] = index of strand2 end position
	# [7] = helix length
	my @allHelix = ([0, 0, 0, 0, 0, 0, 0, 0]);
	
	# The search for stable helices by "sliding" the shorter sequence
	# against the longer one.  First, identify the shorter sequence.
	# The longest HELIX can only be as long as the shortest sequence.
	my $shortSeq = "";
	my $longSeq = "";
	my $seqLength1 = length($seqString1);
	my $seqLength2 = length($seqString2);
	my $order = 0;
	
	if($seqLength1 <= $seqLength2){
		$shortSeq = $seqString1;
		$longSeq = $seqString2;
		$order = 12;
	}
	else{
		$shortSeq = $seqString2;
		$longSeq = $seqString1;
		$order = 21;
	}
	
	# Test alignments of $shortSeq against $longSeq in decreasing size.
	# If a stable helix is found for a pair of alignment coordinates
	# store that helix and continue searching from these coordinates.
	# 
	# $i = $longSeq helix start
	# $j = $shortSeq helix start
	for (my $i = 0; $i <= length($longSeq) - 2; $i ++){
		for (my $j = 0; $j <= length($shortSeq) - 2; $j ++){
			
			# The maximum helix length $k is the lesser of the 
			# remaining length of $shortSeq or $longSeq.
			my $kMax = length($shortSeq) - $j;
			if((length($longSeq) - $i) < (length($shortSeq) - $j)){
				$kMax = length($longSeq) - $i;
			}
			
			for (my $k = $kMax; $k >= 2; $k --){
				my $longBound = substr($longSeq, $i, $k);
				my $shortBound = substr($shortSeq, $j, $k);
				my $dH = 0;
				my $dS = 0;
				my $dG = 0;
				
				# NN Thermodynamic parameters are sequence specific.
				# Maintain the order of sequences from subroutine input.
				if($order == 12){($dH, $dS, $dG) = sumDoubletThermo($shortBound, $longBound);}
				else{($dH, $dS, $dG) = sumDoubletThermo($longBound, $shortBound);}
				
				if($dG < 0){
					my $shortStart = $j;
					my $shortEnd = $j + $k;
					my $longStart = $i;
					my $longEnd = $i + $k;
					my $helixLength = $k;
					
					# Store helix coordinates in the order that the sequences
					# were entered to the subroutine.  Short = seq1, Long = seq2
					if($order == 12){
						push (
							@allHelix,
							[
								$dH,
								$dS,
								$dG,
								$shortStart,
								$shortEnd,
								$longStart,
								$longEnd,
								$helixLength
							]
						);
						
					# Long = seq1, Short = seq2
					}else{
						push (
							@allHelix,
							[
								$dH,
								$dS,
								$dG,
								$longStart,
								$longEnd,
								$shortStart,
								$shortEnd,
								$helixLength
							]
						);
					}
					
	# DO NOT REMOVE ### DO NOT REMOVE ### DO NOT REMOVE ### DO NOT REMOVE ###				
	# 
	# It is appealing and intuitive to think that the longest helix derived
	# from two DNA strands would be the most stable.  After all, the Nearest
	# Neighbor Model is a summation function.  The longest has the most and
	# is therefore the best.  Therefore, it should be perfectly valid to
	# stop testing helices once one has been found for a pair of starting
	# coordinates.
	#
	# DO NOT DO THIS!!!  IT IS WRONG AND WILL LEAD TO NON-OBVIOUS ERRORS.
	# 
	# In many cases, a STABLE helix will have a single base mismatch
	# one base pair internal to the closing base pair.  A smaller helix, 
	# nested internal to this longer one but excluding the internal 
	# mismatch, will often be more stable.
	# 
	# Basically, do not do this:
	# 
	#				$j += $k - 1;
	#				last;
	# 
	# DO NOT REMOVE ### DO NOT REMOVE ### DO NOT REMOVE ### DO NOT REMOVE ###	
	
				}
			}
		}
	}
	
	# Remove the empty initializing helix if there are other entries:
	if(
		(scalar(@allHelix) > 1) &&
		($allHelix[0][2] == 0) &&
		($allHelix[0][3] == 0) &&
		($allHelix[0][4] == 0)
	){splice(@allHelix, 0, 1);}
	
	return (@allHelix);
}

sub calcOrderedThermo {

=head2 calcOrderedThermo

=over

=item Usage:

@orderedHelixThermo = calcOrderedThermo($dnaSeq1, $dnaSeq2);

=item Function:

Calculate the collection of most stable non-overlapping helices between two
DNA sequences based on the Nearest  Neighbor Model of DNA Base Stacking.

=item Arguments:

Two DNA sequences in 5' -> 3' orientation.

=item Returns:

A two dimensional array of helix thermodynamic parameters of the most stable
non-overlapping stable helices.  Each sub-array contains:
[0] = dH, standard enthalpy
[1] = dS, standard entropy
[2] = dG, standard free energy
[3] = index of $dnaSeq1 helix start position
[4] = index of $dnaSeq1 helix end position
[5] = index of $dnaSeq2 helix start position
[6] = index of $dnaSeq2 helix end position
[7] = helix length

Standard thermodynamic parameters are calculated at 37 degrees C and 1M NaCl,
helix strand indeces are of the first and last base of each helix strand 
relative to the input sequences.  The helix coordinates include possible 
terminal mismatch bases at both ends.

=back

=cut
	
	my $seqString1 = uc(shift);
	my $seqString2 = uc(shift);
	
	#print "In calcOrderedThermo\n";
	
	# All stable helices will be stored and returnd in the 
	# two dimensional array @allHelix:
	# [0] = dH
	# [1] = dS
	# [2] = dG
	# [3] = index of strand1 start position
	# [4] = index of strand1 end position
	# [5] = index of strand2 start position
	# [6] = index of strand2 end position
	# [7] = helix length
	my @allHelix = calcAllThermo($seqString1, $seqString2);
	my @stableHelix = ();
	
	# Sort the list by strand1 and strand2 start positions.
	for my $ref (
		sort {
			($a->[3] <=> $b->[3]) ||
			($a->[5] <=> $b->[5])
		} @allHelix
	){
		push (@stableHelix, [@{$ref}]);
	}
	
	# Because the list is sorted by position, we can filter all nested
	# helices in one pass.  Keep filtering until there is no change.
	my @testHelix = ();
	until (@testHelix == @stableHelix){
		@testHelix = @stableHelix;
		for (my $i = 0; $i < scalar(@stableHelix); $i ++){
			unless($stableHelix[$i][2]){splice (@stableHelix, $i, 1); next;}
			for (my $j = $i; $j < scalar(@stableHelix); $j ++){
				if($i == $j){next;}
				
				my $startH1S1 = $stableHelix[$i][3];
				my $endH1S1 = $stableHelix[$i][4];
				my $startH1S2 = $stableHelix[$i][5];
				my $endH1S2 = $stableHelix[$i][6];
				
				my $startH2S1 = $stableHelix[$j][3];
				my $endH2S1 = $stableHelix[$j][4];
				my $startH2S2 = $stableHelix[$j][5];
				my $endH2S2 = $stableHelix[$j][6];
				
				# If the two helices do not overlap on both strands,
				# proceed to the next pair.
				if(
					($endH1S1 < $startH2S1) &&
					($startH1S2 > $endH2S2)
				){last;}
				
				# If both strands of both helices are nested within each other,
				if(
					(
						(($startH1S1 <= $startH2S1) && ($endH1S1 >= $endH2S1)) ||
						(($startH1S1 >= $startH2S1) && ($endH1S1 <= $endH2S1))
					) && (
						(($startH1S2 <= $startH2S2) && ($endH1S2 >= $endH2S2)) ||
						(($startH1S2 >= $startH2S2) && ($endH1S2 <= $endH2S2))
					)
				){
					# Remove the helix that is both shorter AND less stable.
					if(
						($stableHelix[$i][2] <= $stableHelix[$j][2]) &&	# helix i is more stable
						($stableHelix[$i][7] >= $stableHelix[$j][7])	# helix i is as long or longer
					){splice (@stableHelix, $j, 1); next;}
					
					elsif(
						($stableHelix[$i][2] > $stableHelix[$j][2]) &&	# helix j is more stable
						($stableHelix[$i][7] <= $stableHelix[$j][7])	# helix j is as long or longer
					){splice (@stableHelix, $i, 1); last;}
				}
			}
		}
		
		# Re-sort the list by strand1 start position.
		my @tempList = ();
		for my $ref (
			sort {
				($a->[3] <=> $b->[3]) ||
				($a->[5] <=> $b->[5])
			} @stableHelix
		){
			push (@tempList, [@{$ref}]);
		}
		@stableHelix = @tempList;
	}
	return (@stableHelix);
}

sub calcMaxThermo {

=head2 calcMaxThermo

=over

=item Usage:

($dH, $dS, $dG, $start1, $end1, $start2, $end2, $helixLength) =
Bio::JParker::DnaThermodynamics::calcMaxThermo($seqString1, $seqString2);

=item Function:

Calculate the most stable helix by the Nearest Neighbor Model of 
Thermodynamics for two DNA sequences.  Every possible helix is calculated
and tested to identify the optimum pairing.

=item Arguments:

Two DNA sequences in 5' -> 3' orientation.

=item Returns:

Thermodynamic parameters of the most stable helix: standard enthalpy (delta H)
and entropy (delta S) and free energy (delta G) at 37 degrees C and 1M NaCl,
index of the first and last base of each helix strand relative to the input
sequences and the helix length.  The helix coordinates include possible 
terminal mismatch bases at both ends.

=back

=cut
	
	my $seqString1 = uc(shift);
	my $seqString2 = uc(shift);
	
	#print "In calcMaxThermo\n";
	
	# calcAllThermo returns a list of all non-nested stable helices
	# between $seqString1 and $seqString2.  Sort this list by
	# ascending free energy and return the most stable helix.
	my @allHelix = calcAllThermo($seqString1, $seqString2);
	my @sorted = ();
	
	for my $refLoc (sort {$a ->[2] <=> $b->[2]} @allHelix){
		push (@sorted, [@{$refLoc}]);
	}
	
	return (@{$sorted[0]});
}

sub calcDnaTm {

=head2 calcDnaTm

=over

=item Usage:

($tm, $dG) = 
calcDnaTm($seqString1, $seqString2, $dnaConc1, $dnaConc2, $saltConc);

=item Function:

Calculates the melting temperature of a double stranded DNA strand.  The Tm 
is extrapolated from the hybridization free energy, calculated with 
Bio::JParker::DnaThermodynamics::sumDoubletThermo.  The monovalent salt 
adjustment is calculated as described by Owczarzy and Behlke, Calculation 
of Tm for Oligonucleotide Duplexes, Integrated DNA Technologies whitepaper 
(2005).

=item Arguments:

Two DNA sequences in 5' -> 3' orientation, concentration of the DNA species
(DNA1 and DNA2) and concentration of monovalent salt (NaCl or KCl)in Molar.

=item Returns:

Predicted melting temperature in degrees C and free energy in kcal/ mol

=back

=cut
	
	my $seqString1 = shift;
	my $seqString2 = shift;
	my $dnaConc1 = shift;
	my $dnaConc2 = shift;
	my $saltConc = shift;
	
	# The DNA is assumed to be non-self complimentary and of equal
	# concentration, if this is not the case make the necessary
	# adjustments.
	my $dnaConc = $dnaConc1;
	if(($dnaConc1 != $dnaConc2) && ($dnaConc2 != 0)){
		if ($dnaConc1 > $dnaConc2){$dnaConc = ($dnaConc1 - $dnaConc2)/2;}
		elsif($dnaConc1 < $dnaConc2){$dnaConc = ($dnaConc2 - $dnaConc1)/2;}
	}
	
	# Calculate the nearest neighbor model Tm at pH 7 and 1M NaCl.
	# R = 1.9858775 cal/K mol 
	# (http://en.wikipedia.org/wiki/Gas_constant#cite_note-0)
	my($dH, $dS, $dG) = sumDoubletThermo ($seqString1, $seqString2);
	my $nnTm = 0;
	if($dS && $dnaConc){$nnTm = (($dH * 1000) / ($dS + (1.9858775 * log($dnaConc))));}
	
	# Calculate the mean fraction GC content of the sequences
	my $gcFraction1 = calcGcFraction($seqString1);
	my $gcFraction2 = calcGcFraction($seqString2);
	my $gcFraction = ($gcFraction1 + $gcFraction2) / 2;
	
	# Calculate the salt concentration adjustment
	my $saltAdjustment = calcSaltAdjustment($gcFraction, $saltConc);
	
	# Apply salt adjustment and convert from Kelvin to Celsius
	my $adjTm = 0;
	if($nnTm){$adjTm = (1 / ((1 / $nnTm) + $saltAdjustment)) - 273.15;}
	
	#print "calcDnaTm: $dnaConc\t$dnaConc1\t$dnaConc2\t$dH\t$dS\t$dG\t$gcFraction\t$nnTm\t$adjTm\n";
	
	return ($adjTm, $dG);
}

sub calcMaxTm {


=head2 calcMaxTm

=over

=item Usage:

($tm, $dG) = 
calcMaxTm($seqString1, $seqString2, $dnaConc1, $dnaConc2, $saltConc);

=item Function:

Calculates the maximum melting temperature of a double stranded DNA strand.
The Tm is extrapolated from the hybridization free energy, calculated with 
Bio::JParker::DnaThermodynamics::calcMaxThermo.  The monovalent salt 
adjustment is calculated as described by Owczarzy and Behlke, Calculation 
of Tm for Oligonucleotide Duplexes, Integrated DNA Technologies whitepaper 
(2005).

NOTE: To calculate the melting temperature of a a DNA strand and its reverse
complement use calcDnaTm instead.

=item Arguments:

Two DNA sequences in 5' -> 3' orientation, concentration of the DNA species 
(DNA1 and DNA2) and concentration of monovalent salt (NaCl or KCl)in Molar.

=item Returns:

Predicted melting temperature in degrees C and free energy in kcal / mol

=back

=cut
	
	my $seqString1 = shift;
	my $seqString2 = shift;
	my $dnaConc1 = shift;
	my $dnaConc2 = shift;
	my $saltConc = shift;
	
	# [0] = dH
	# [1] = dS
	# [2] = dG
	# [3] = index of strand1 start position
	# [4] = index of strand1 end position
	# [5] = index of strand2 start position
	# [6] = index of strand2 end position
	# [7] = helix length
	# Calculate the optimal nearest neighbor model Tm at pH 7 and 1M NaCl
	my (undef, undef, undef, $start1, undef, $start2, undef, $length) = calcMaxThermo ($seqString1, $seqString2);
	my $subSeq1 = substr($seqString1, $start1, $length);
	my $subSeq2 = substr($seqString2, $start2, $length);
	return (calcDnaTm($subSeq1, $subSeq2, $dnaConc1, $dnaConc2, $saltConc));
}

sub calcGcFraction {

=head2 calcGcFraction

=over

=item Usage:

$gcFraction = calcGcFraction($seqString);

=item Function:

Calculate the GC fraction (fractional, not percent) GC content of a DNA sequence.

=item Arguments:

A DNA seqence text string

=item Returns:

The fractional GC content of the sequence string between 0 and 1.

=back

=cut

	my $seqString = shift;
	my $numGC = grep(/[GC]/g, split(//, $seqString));
	my $length = length($seqString);
	if($length){return ($numGC / $length);}
	else{return (0);}
}

sub calcSaltAdjustment{

=head2 calcSaltAdjustment

=over

=item Usage:

$adjustment = calcSaltAdjustment($seqString, $dnaConc, $saltConc);

=item Function:

Calculates the salt concentration correction factor for melting temperature 
in 1 / K as described in Owczarzy, et. al, http://www.idtdna.com/support/
technical/TechnicalBulletinPDF/Calculation_of_Tm_for_Oligonucleotide_
Duplexes.pdf

=item Arguments:

Sequence GC fraction (0 - 1) and Molar monovalent salt concentration.

=item Returns:

Salt concentration adjustment factor in 1 / K.

=back

=cut
	
	my $gcFraction = shift;
	my $saltConc = shift;
	
	my $saltLog = log($saltConc);
	my $adjustment = ((((4.29 * $gcFraction) - 3.95)  * $saltLog) + (0.94 * ($saltLog ** 2))) * 10**-5;
	return ($adjustment);
}

############# HASH LOOKUP SUBROUTINES ##################
# The subroutines:
# 	getDanglingThermo
# 	getEndThermo
#	getMidThermo
# 
# are hash constant lookup subroutines.  They return
# array values from the module constant hashes 
# 
# 	%danglingThermoHash
#	%endThermoHash
#	%midThermoHash
# 
# respectively

sub getDanglingThermo {

=head2 getDanglingThermo

=over

=item Usage:

($dH, $dS, $dG) = getDanglingThermo($plusPair, $minusPair);

=item Function:

Returns the nearest neighbor thermodynamic parameters of terminal dangling
end sequences (a pair of matched bases next to a single unpaired nucleotide)
as described in SantaLucia and Hicks, Annu Rev Biophys Biomol Struct 33, 
415-440 (2004).

=item Arguments:

Two DNA doublet sequence strings in 5' -> 3' and 3' -> 5' orientation 
respectively (SantaLucia format: NN1/NN2 = 5'-NN1-3' / 3'-NN2-5').  The
missing nucleotide should be indicated by a dash ( - ).

=item Returns:

Standard enthalpy (delta H), entropy (delta S)  and free energy (delta G) at
37 degrees C and 1M NaCl.

=back

=cut
	
#	print "GETTING DANGLING THERMO\n";

	my $plusPair = uc(shift);
	my $minusPair = uc(shift);
	
	if(exists($danglingThermoHash{$plusPair}{$minusPair})){
		return @{$danglingThermoHash{$plusPair}{$minusPair}};
	}
	else{return (0,0,0);}
}

sub getEndThermo {

=head2 getEndThermo

=over

=item Usage:

($dH, $dS, $dG) = getEndThermo($plusPair, $minusPair);

=item Function:

Returns the nearest neighbor thermodynamic parameters of TERMINAL (helix
end) matched and single base mismatch doublets of nucleotides.  Terminal
mismatch values were determined from computational experiments using the
Unafold server:

http://dinamelt.bioinfo.rpi.edu/quikfold.php

Values for matched doublets are identical to the internal helix nearest
neighbor model values.  They are replicated here for convenience.

=item Arguments:

Two DNA doublet sequence strings in 5' -> 3' and 3' -> 5'orientation 
respectively (SantaLucia format: NN1/NN2 = 5'-NN1-3' / 3'-NN2-5').

=item Returns:

Standard enthalpy (delta H), entropy (delta S) and free energy (delta G) at
37 degrees C and 1M NaCl.

=back

=cut
	
	my $plusPair = uc(shift);
	my $minusPair = uc(shift);
	
	# If either base pair contains a dash character it indicates that
	# it is the terminal base of the DNA molecule.  Return the Dangling
	# End thermodynamic paramters instead.  Otherwise return the
	# terminal base pair thermodynamic parameters.
	if(($plusPair =~ /-/) || ($minusPair =~ /-/)){
		return(getDanglingThermo($plusPair, $minusPair));
	}
	elsif(exists($endThermoHash{$plusPair}{$minusPair})){
		return(@{$endThermoHash{$plusPair}{$minusPair}});
	}
	else{return (0,0,0)};
}

sub getMidThermo {

=head2 getMidThermo

=over

=item Usage:

($dH, $dS, $dG) = getMidThermo($plusPair, $minusPair);

=item Function:

Returns the nearest neighbor thermodynamic parameters of matched and single
base mismatch doublets of nucleotides described in SantaLucia and Hicks,
Annu Rev Biophys Biomol Struct 33, 415-440 (2004).

THESE VALUES ARE NOT VALID FOR TERMINAL MISMATCHES!!!
Use Bio::JParker::DnaThermodynamics::getEndThermo for base pairs at the end
of the DNA duplex or = Bio::JParker::DnaThermodynamics::getDanglingThermo 
for dangling (unmatched) terminal ends.

=item Arguments:

Two DNA doublet sequence strings in 5' -> 3' and 3' -> 5' orientation
respectively (SantaLucia format: NN1/NN2 = 5'-NN1-3' / 3'-NN2-5').

=item Returns:

Standard enthalpy (delta H), entropy (delta S)  and free energy (delta G)
at 37 degrees C and 1M NaCl.

=back

=cut
	
	my $plusPair = uc(shift);
	my $minusPair = uc(shift);
	
	if(exists($midThermoHash{$plusPair}{$minusPair})){
		return @{$midThermoHash{$plusPair}{$minusPair}};
	}
	else{return (0,0,0);}
}

############# DNA LOOP ENERGY CALCULATION SUBROUTINES ##################
# 
# The subroutines:
# 	calcBigLoopEnergy
# 	calcBulgEnergy
# 	calcInternalLoopEnergy
# 	calcHairpinEnergy
# 	calcTriHairpinEnergy
# 	calcTetraHairpinEnergy
# 
# are used to calculate the FREE ENERGY of inter-helix regions of
# single stranded DNA instability (loops).
# 
sub calcBigLoopEnergy {

=head2 calcBigLoopEnergy

=over

=item Usage:

$dG = calcBigLoopEnergy($dGX, $lengthX, $lengthN);

=item Function:

Calculate the Jacobson-Stockmayer entropy extrapolation for long DNA loops
described in SantaLucia and Hicks, Annu Rev Biophys Biomol Struct 33, 
415-440 (2004).

=item Arguments:

The measured free energy of a loop of length X, the corresponding length
of loop X, and the length of unknown energy loop N.

=item Returns:

Free energy of the hairpin loop at 37 degrees C and 1M NaCl.

=back

=cut
	
	my $dGX = shift;
	my $loopLengthX = shift;
	my $loopLengthN = shift;
	
	# R = 0.0019858775 kcal/K mol
	# (http://en.wikipedia.org/wiki/Gas_constant#cite_note-0)
	return ($dGX + (2.44 * 0.0019858775 * 310.15 * log($loopLengthN / $loopLengthX)));
}


sub calcBulgeEnergy {

=head2 calcBulgeEnergy

=over

=item Usage:

$dG = calcBulgeEnergy($seqString1, $seqString2);

=item Function:

Calculate the free energy of a bulge loop comprised of  DNA 
sequence $seqString1 and $seqString2 using the thermodynamic 
parameters described in SantaLucia and Hicks, Annu Rev Biophys
Biomol Struct 33, 415-440 (2004).

=item Arguments:

Two DNA sequence strings in 5' -> 3' orientation.

=item Returns:

Free energy of the bulge loop at 37 degrees C and 1M NaCl.

=back

=cut

	# Input sequences are in 5'->3' orientation
	my $seqString1 = uc(shift);
	my $seqString2 = uc(shift);
	
	my $shortSeq	= "";
	my $longSeq	 = "";
	my $shortLength = 0;
	my $longLength  = 0;
	my $sumG		= 0;
	
	if (length($seqString1) <= length($seqString2)) {
		$shortSeq = $seqString1;
		$longSeq  = reverse($seqString2);
	} else {
		$shortSeq = $seqString2;
		$longSeq  = reverse($seqString1);
	}
	
	$shortLength = length($shortSeq);
	$longLength  = length($longSeq);
	
	# If the two sequences are the same length, or the short sequence is
	# more than two bases long, they cannot form a bulge loop.
	if ($shortLength > 2) {
		warn
		  "ERROR: Bio::JParker::DnaThermodynamics::calcBulgeEnergy:"
		. " Invalid short sequence length.  The short sequence of bulge"
		. " loops must be two bases.\n";
		return 0;
	}

  BULGE_SWITCH: {
		($longLength - 2) >= 30 && do {
			$sumG += calcBigLoopEnergy(5.9, 30, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 25 && do {
			$sumG += calcBigLoopEnergy(5.6, 25, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 20 && do {
			$sumG += calcBigLoopEnergy(5.3, 20, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 18 && do {
			$sumG += calcBigLoopEnergy(5.2, 18, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 16 && do {
			$sumG += calcBigLoopEnergy(5, 16, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 14 && do {
			$sumG += calcBigLoopEnergy(4.8, 14, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 12 && do {
			$sumG += calcBigLoopEnergy(4.5, 12, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) >= 10 && do {
			$sumG += calcBigLoopEnergy(4.3, 10, $longLength);
			last BULGE_SWITCH;
		};
		($longLength - 2) == 9 && do {$sumG += 4.1; last BULGE_SWITCH;};
		($longLength - 2) == 8 && do {$sumG += 3.9; last BULGE_SWITCH;};
		($longLength - 2) == 7 && do {$sumG += 3.7; last BULGE_SWITCH;};
		($longLength - 2) == 6 && do {$sumG += 3.5; last BULGE_SWITCH;};
		($longLength - 2) == 5 && do {$sumG += 3.3; last BULGE_SWITCH;};
		($longLength - 2) == 4 && do {$sumG += 3.2; last BULGE_SWITCH;};
		($longLength - 2) == 3 && do {$sumG += 3.1; last BULGE_SWITCH;};
		($longLength - 2) == 2 && do {$sumG += 2.9; last BULGE_SWITCH;};

		# Bulge loops of one have free energy of +4.0 kcal/mol plus the
		# closing base pair stack energy.
		($longLength - 2) == 1 && do {
			$sumG += 4;
			
			# Extract the end bases of $longSeq in 3' <- 5' orientation.
			my $longEnd = substr($longSeq, 0, 1) . substr($longSeq, -1);
			my (undef, undef, $dG) = getMidThermo($shortSeq, $longEnd);
			$sumG += $dG;
			return ($sumG);
		};
	}
	
	return ($sumG);
}

sub calcInternalLoopEnergy {

=head2 calcInternalLoopEnergy

=over

=item Usage:

$dG = calcInternalLoopEnergy($seqString1, $seqString2);

=item Function:

Calculate the free energy of an internal loop comprised of DNA 
sequence $seqString1 and $seqString2 using the thermodynamic 
parameters described in SantaLucia and Hicks, Annu Rev Biophys
Biomol Struct 33, 415-440 (2004).

=item Arguments:

Two DNA sequence strings in 5' -> 3' orientation.

=item Returns:

Free energy of the internal loop at 37 degrees C and 1M NaCl.

=back

=cut

	# Input sequences are in 5'->3' orientation
	my $seqString1 = uc(shift);
	my $seqString2 = uc(shift);
	
	my $shortSeq	= "";
	my $longSeq	 = "";
	my $shortLength = 0;
	my $longLength  = 0;
	my $sumG		= 0;
	
	if (length($seqString1) <= length($seqString2)) {
		$shortSeq = $seqString1;
		$longSeq  = reverse($seqString2);
	} else {
		$shortSeq = $seqString2;
		$longSeq  = reverse($seqString1);
	}
	$shortLength = length($shortSeq);
	$longLength  = length($longSeq);
	
	INTER_LOOP: {
		($longLength - 2) >= 30 && do {
			$sumG += calcBigLoopEnergy(6.6, 30, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 25 && do {
			$sumG += calcBigLoopEnergy(6.3, 25, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 20 && do {
			$sumG += calcBigLoopEnergy(5.9, 20, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 18 && do {
			$sumG += calcBigLoopEnergy(5.8, 18, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 16 && do {
			$sumG += calcBigLoopEnergy(5.6, 16, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 14 && do {
			$sumG += calcBigLoopEnergy(5.4, 14, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 12 && do {
			$sumG += calcBigLoopEnergy(5.2, 12, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) >= 10 && do {
			$sumG += calcBigLoopEnergy(4.9, 10, $longLength);
			last INTER_LOOP;
		};
		($longLength - 2) == 9 && do {$sumG += 4.9; last INTER_LOOP;};
		($longLength - 2) == 8 && do {$sumG += 4.8; last INTER_LOOP;};
		($longLength - 2) == 7 && do {$sumG += 4.6; last INTER_LOOP;};
		($longLength - 2) == 6 && do {$sumG += 4.4; last INTER_LOOP;};
		($longLength - 2) == 5 && do {$sumG += 4.0; last INTER_LOOP;};
		($longLength - 2) == 4 && do {$sumG += 3.6; last INTER_LOOP;};
		($longLength - 2) == 3 && do {$sumG += 3.2; last INTER_LOOP;};
		
		# Internal loops of length 2 are treated as adjacent single
		# base mismatches.
		($longLength - 2) == 2 && do {
			my (undef, undef, $dG1) =
			  getMidThermo(substr($shortSeq, 0, 2), substr($longSeq, 0, 2));
			my (undef, undef, $dG2) =
			  getMidThermo(substr($shortSeq, -2), substr($longSeq, -2));
			$sumG += $dG1 + $dG2;
		};
	}
	
	# If the two sequences are not the same length, add an assymetry
	# penalty.
	if ($shortLength != $longLength) {
		$sumG += (0.3 * ($longLength - $shortLength));
	}
	
	# Add the terminal base energy for both ends of long internal loops.
	if (($longLength - 2) > 2) {
		my (undef, undef, $dG1) =
			getEndThermo(substr($shortSeq, 0, 2), substr($longSeq, 0, 2));
		my (undef, undef, $dG2) =
			getEndThermo(substr($shortSeq, -2), substr($longSeq, -2));
		$sumG += $dG1 + $dG2;
	}
	
	return ($sumG);
}

sub calcHairpinEnergy {

=head2 calcHairpinEnergy

=over

=item Usage:

$dG = calcHairpinEnergy($loopSeq);

=item Function:

Calculate the free energy of a hairpin loop comprised of the
DNA sequence $loopSeq using the thermodynamic parameters
described in SantaLucia and Hicks, Annu Rev Biophys
Biomol Struct 33, 415-440 (2004).

=item Arguments:

One DNA sequence strings in 5' -> 3' orientation.

=item Returns:

Free energy of the hairpin loop at 37 degrees C and 1M NaCl.

=back

=cut

	my $loopSeq	= uc(shift);
	my $loopLength = length($loopSeq);
	my $sumG	   = 0;
	
	# Hairpin loops of length three or four have potentially stable
	# thermodynamics.
	if	(($loopLength - 2) == 4) {return (calcTetraHairpinEnergy($loopSeq));}
	elsif (($loopLength - 2) == 3) {return (calcTriHairpinEnergy($loopSeq));}
	
	HAIR_LOOP: {
		($loopLength - 2) >= 30 && do {
			$sumG += calcBigLoopEnergy(6.3, 30, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 25 && do {
			$sumG += calcBigLoopEnergy(6.1, 25, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 20 && do {
			$sumG += calcBigLoopEnergy(5.7, 20, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 18 && do {
			$sumG += calcBigLoopEnergy(5.5, 18, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 16 && do {
			$sumG += calcBigLoopEnergy(5.3, 16, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 14 && do {
			$sumG += calcBigLoopEnergy(5.1, 14, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 12 && do {
			$sumG += calcBigLoopEnergy(5, 12, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) >= 10 && do {
			$sumG += calcBigLoopEnergy(4.6, 10, $loopLength - 2);
			last HAIR_LOOP;
		};
		($loopLength - 2) == 9 && do {$sumG += 4.5; last HAIR_LOOP;};
		($loopLength - 2) == 8 && do {$sumG += 4.3; last HAIR_LOOP;};
		($loopLength - 2) == 7 && do {$sumG += 4.2; last HAIR_LOOP;};
		($loopLength - 2) == 6 && do {$sumG += 4;   last HAIR_LOOP;};
		($loopLength - 2) == 5 && do {$sumG += 3.3; last HAIR_LOOP;};
	}
	
	# Add the energetic contribution of the closing base pair for
	# long loops.
	my $plusPair = substr($loopSeq, 0, 2);
	my $minusPair = reverse(substr($loopSeq, -2, 2));
	my (undef, undef, $dG1) = getEndThermo($plusPair, $minusPair);
	$sumG += $dG1;

	return ($sumG);
}

sub calcTriHairpinEnergy {


=head2 calcTriHairpinEnergy

=over

=item Usage:

$dG = calcTriHairpinEnergy($loopSeq);

=item Function:

Calculate the free energy of triplet hairpin loop sequences as described
in SantaLucia and Hicks, Annu Rev Biophys BiomolStruct 33, 415-440 (2004).
Three base hairpins containging GNA (N = any base) are energetically stable.

=item Arguments:

Loop sequence is 5' -> 3' including loop closing bases.

=item Returns:

Free energy of the hairpin loop at 37 degrees C and 1M NaCl.

=back

=cut
	
	my $loopSeq = uc(shift);
	
	# Triloop initial free energy is 3.5 kcal / mol
	my $sumG = 3.5;
	
	# Apply terminal AT penalty if the loops is closed with AT.
	# The closing base pairs must be matched so only one side
	# needs to be tested.
	if(substr($loopSeq, 0, 1) eq ('A'||'T')){$sumG += 0.05;}
	
	# Add triloop stability bonus if available.
	if(exists($tripletLoopEnergyHash{$loopSeq})){$sumG += @{$tripletLoopEnergyHash{$loopSeq}}[0];}
	return ($sumG);
}

sub calcTetraHairpinEnergy {

=head2 calcTetraHairpinEnergy

=over

=item Usage:

$dG = calcTetraHairpinEnergy($loopSeq);

=item Function:

Calculate the free energy of tetraloop (4 base) sequences as  described
in SantaLucia and Hicks, Annu Rev Biophys Biomol Struct 33, 415-440 (2004).

=item Arguments:

Loop sequence is 5' -> 3' including loop closing bases.

=item Returns:

Free energy of the hairpin loop at 37 degrees C and 1M NaCl.

=back

=cut
	
	my $loopSeq = uc (shift);
	
	# Tetraloop initial free energy is 3.5 kcal / mol
	my $sumG = 3.5;
	
	# Add tetraloop stability bonus if available.
	if(exists($tetraLoopEnergyHash{$loopSeq})){$sumG += @{$tetraLoopEnergyHash{$loopSeq}}[0];}
	
	# Add the energetic contribution of the closingbase pair.
	my $plusPair = substr($loopSeq, 0, 2);
	my $minusPair = reverse(substr($loopSeq, -2));
	my (undef, undef, $dG1) = getEndThermo($plusPair, $minusPair);
	$sumG += $dG1;
	
	return ($sumG);
}

1;
__END__

=head1 SEE ALSO

For complete documentation of the Nearest Neighbor Model of DNA 
Thermodynamics, please refer to:

The Thermodynamics of DNA Structural Motifs
SantaLucia and Hicks, Annu Rev Biophys Biomol Struct 33, 415-440 (2004)

For other documentation of the UNAFold Nucleic Acid secondary structure
prediction application, please refer to:

Mfold web server for nucleic acid folding and hybridization prediction.
Zuker, Nucleic Acids Res. 31 (13), 3406-15, (2003)

Expanded Sequence Dependence of Thermodynamic Parameters Improves 
Prediction of RNA Secondary Structure.
Mathews, Sabina, Zuker and Turner, J. Mol. Biol. 288, 911-940 (1999)

=head1 AUTHOR

Jefferson Parker, E<lt>jeffersonparker@febit.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 Jefferson Parker, ALL RIGHTS RESERVED

Disclaimer of Warranty.

THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY 
APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT 
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM �AS IS� WITHOUT WARRANTY 
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, 
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM 
IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF 
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

Limitation of Liability.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING 
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR 
CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, 
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT 
NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES 
SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO 
OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY 
HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

=cut
