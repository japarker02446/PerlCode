#!usr/bin/perl
package Bio::JParker::ProbeDesign;

# Copyright 2009, Jefferson A. Parker, Febit Inc.
# ALL RIGHTS RESERVED

# This module contains a collection of subroutines that are shared by the 
# Bio::JParker collection of probe design programs.

# Suppress 'Use of uninitialized value' warning messages.
no warnings 'uninitialized'; 

# Initialize libraries
use 5.008008;
use Bio::JParker::Shared;
use Bio::SeqIO;
use strict;
use warnings;

# Set global variables
our $VERSION = '1.0';
our $genomeDir = Bio::JParker::Shared::whereisDirectory('genomes');
our $dataDir = Bio::JParker::Shared::whereisDatabase();
our %nmerHash = ();

our %dubMisHash = (
	'AA' => 'AC',
	'AC' => 'AT',
	'AG' => 'AC',
	'AT' => 'AC',
	'CA' => 'CC',
	'CC' => 'CT',
	'CG' => 'CC',
	'CT' => 'CC',
	'GA' => 'GC',
	'GC' => 'GT',
	'GG' => 'GC',
	'GT' => 'GC',
	'TA' => 'TC',
	'TC' => 'TT',
	'TG' => 'TC',
	'TT' => 'TC',
);

our %tripMisHash = (
	'AAA' => 'ACA',
	'AAC' => 'ACC',
	'AAG' => 'ACG',
	'AAT' => 'ACT',
	'ACA' => 'AAA',
	'ACC' => 'ATC',
	'ACG' => 'AAG',
	'ACT' => 'ATT',
	'AGA' => 'AAA',
	'AGC' => 'ACC',
	'AGG' => 'AAG',
	'AGT' => 'ACT',
	'ATA' => 'ACA',
	'ATC' => 'ACC',
	'ATG' => 'ACG',
	'ATT' => 'ACT',
	'CAA' => 'CCA',
	'CAC' => 'CCC',
	'CAG' => 'CCG',
	'CAT' => 'CCT',
	'CCA' => 'CAA',
	'CCC' => 'CTC',
	'CCG' => 'CAG',
	'CCT' => 'CTT',
	'CGA' => 'CAA',
	'CGC' => 'CCC',
	'CGG' => 'CAG',
	'CGT' => 'CCT',
	'CTA' => 'CCA',
	'CTC' => 'CCC',
	'CTG' => 'CCG',
	'CTT' => 'CCT',
	'GAA' => 'GCA',
	'GAC' => 'GCC',
	'GAG' => 'GCG',
	'GAT' => 'GCT',
	'GCA' => 'GAA',
	'GCC' => 'GTC',
	'GCG' => 'GAG',
	'GCT' => 'GTT',
	'GGA' => 'GAA',
	'GGC' => 'GCC',
	'GGG' => 'GAG',
	'GGT' => 'GCT',
	'GTA' => 'GCA',
	'GTC' => 'GCC',
	'GTG' => 'GCG',
	'GTT' => 'GCT',
	'TAA' => 'TCA',
	'TAC' => 'TCC',
	'TAG' => 'TCG',
	'TAT' => 'TCT',
	'TCA' => 'TAA',
	'TCC' => 'TTC',
	'TCG' => 'TAG',
	'TCT' => 'TTT',
	'TGA' => 'TAA',
	'TGC' => 'TCC',
	'TGG' => 'TAG',
	'TGT' => 'TCT',
	'TTA' => 'TCA',
	'TTC' => 'TCC',
	'TTG' => 'TCG',
	'TTT' => 'TCT',
);

sub buildNmerHash {
	
=head2
=over5
=item buildNmerHash
Usage: 		Bio::JParker::ProbeDesign::buildNmerHash($file, $nmerSize)
Function:	Parse and quantify the number of times every sub-sequence of 
			$nmerSize appears in each sequence within $file and store 
			the count in the global %nmerHash as a DBM hash file.  The
			resulting DBM hash file is named according to the input file
			name and nmer size.
Arguments:	The name of a FASTA formatted DNA sequence file in
			the Bio::JParker::Shared designated genome sequence directory.
Returns:	Directory path of the DBM hash file containing the subsequence
			quantification.
=back
=cut
	
	my $file = shift;
	my $nmerSize = shift;
	
	my $inFile = "$genomeDir"."\/$file";
	my $dbmFile = "$dataDir"."\/$file";
	my ($date, $time) = Bio::JParker::Shared::kronos();
	
	# The DBM File is named by the source sequence file and nmer length.
	$dbmFile =~ s/\.fasta//;
	$dbmFile .= "_$nmerSize";
	dbmopen(%nmerHash, $dbmFile, 0666) or die "Cannot open file $dbmFile: $!\n";
	
	# Open a SeqIO stream.
	my $seqStream = Bio::SeqIO -> new (
			-file => $inFile,
			-alphabet => "Dna",
			-format => "Fasta"
		);
	
	# Parse every plus and minus strand sequence to the hash.
	while(my $nextSeq = $seqStream -> next_seq()){
		my $sequence = $nextSeq -> seq();
		my $revSeq = Bio::JParker::ProbeDesign::reverseComplement($sequence);
		countNmer ($sequence, $nmerSize);
		countNmer ($revSeq, $nmerSize);
	}
	
	# Close the SeqIO stream and DBM file.
	$seqStream -> DESTROY();
	dbmclose (%nmerHash);
	return ($dbmFile);
}

sub getNmerHash {

=head2
=over5
=item getNmerHash
Usage: 
Function: 	Sum all the nmers for the files in the list
Arguments:	List of files to build the hash from.
Returns:	Reference to the hash.
=back
=cut



}

sub countNmer {
	
=head2
=over5
=item countNmer
Usage: Bio::JParker::ProbeDesign::countNmer($seqString, $nmerSize);
Function: Parse and quantify the number of times every sequence of 
		$nmerSize appears in $seqString and store it in the global
		%nmerHash.
Arguments:	A DNA sequence string and nmer length value.
Returns:	1
=back
=cut

	my $sequence = shift;
	my $nmerSize = shift;
	my $seqLength = length($sequence);
	
	for (my $i = 0; $i < ($seqLength - $nmerSize); $i ++){
		$nmerHash{substr($sequence, $i, $nmerSize)} += 1;
	}
	return (1);
}

sub designMismatchProbe {
=head2
=over5
=item designMismatchProbe
Usage: 		$mismatchSeqString = Bio::JParker::ProbeDesign::designMismatchProbe
		($seqString, $replaceBase);
Function:	Design the best mismatch of $seqString by replacing the base at 
		$replaceBase with the maximally destabilizing nucleotide at the
		position $replaceBase.  If $replaceBase is at the end of the
		probe sequence, doublet mismatch values are used.  If it is in
		the interior of the sequence, triplet mismatches are applied.
Arguments:	The 5' -> 3' sequence of a DNA probe and the interger location
		of the base to be replaced, indexed from a start position of 1.
Returns:	Energetic maximum mismatch sequence at the replacement site.
=back
=cut

	my $probeSeq = shift;
	my $replaceBase = shift;
	
	my $matchSeq = "";
	my $misMatchSeq = "";
	
	# If the replacing the first base, we have to identify the mismatch 
	# doublet of the reverse complement of the first two bases.
	if($replaceBase == 1){
		$matchSeq = reverseComplement(substr($probeSeq, 0, 2));
		$misMatchSeq = reverseComplement($dubMisHash{$matchSeq});
		substr($probeSeq, 0, 2) = $misMatchSeq;
	}
	
	# If replacing the last base, simply swap the mismatch doublet.
	elsif($replaceBase == length($probeSeq)){
		$matchSeq = substr($probeSeq, -2);
		$misMatchSeq = $dubMisHash{$matchSeq};
		substr($probeSeq, -2, 2) = $misMatchSeq;
	}
	
	# Identify the triplet surrounding $replaceBase and retrieve
	# it's maximally destabilizing replacement from the hash.
	else{
		$matchSeq = substr($probeSeq, ($replaceBase - 2), 3);
		$misMatchSeq = $tripMisHash{$matchSeq};
		substr($probeSeq, ($replaceBase - 2), 3) = $misMatchSeq;
	}
	return ($probeSeq);
}

sub hasAmbiguousBase {
=head2
=over5
=item hasAmbiguousBase
Usage: 		$skipTo = Bio::JParker::ProbeDesign::hasAmbiguousBase($seqString)
Function:	Test if the DNA sequence string $seqString has an ambiguous 
		IUPAC base code (not ACGT)8.
Arguments:	The 5' -> 3' sequence of a DNA probe.
Returns:	The index of the ambiguous base plus one (the index of the next
		non-ambiguous base) if present or 0.
=back
=cut

	my $seqString = shift;
	if($seqString =~ /([RYMKSWHBVDN])/){return(index($seqString, $1) + 1);}
	else{return(0);}
}

sub hasNoFivePrimeSS {
=head2
=over5
=item hasNoFivePrimeSS
Usage: 		$skipTo = Bio::JParker::ProbeDesign::hasNoFivePrimeSS($seqString)
Function:	Test if the sequence string DOES NOT start with SS (G or C).
Arguments:	The 5' -> 3' sequence of a DNA probe.
Returns:	Returns the index of the last non-GC if true or 0 if false.
=back
=cut

	my $seqString = shift;
	if($seqString =~ /^[CG][CG]/){return(0);}			# SS, pass
	elsif($seqString =~ /^([CG][^CG]+)/){return(length($1));} 	# S_+, fail
	elsif($seqString =~ /^([^CG]+)/){return(length($1));}		# W+, fail
}

sub hasNoThreePrimeSSW {
=head2
=over5
=item hasNoThreePrimeSSW
Usage: 		$skipTo = Bio::JParker::ProbeDesign::hasNoThreePrimeSSW($seqString)
Function:	Test if the sequence string DOES NOT end in SSW (S = G or C, 
		W = A or T).
Arguments:	The 5' -> 3' sequence of a DNA probe.
Returns:	Returns 1 if true or 0 if false.
=back
=cut

	my $seqString = shift;
	if($seqString !~ /[CG][CG][AT]$/){return(1);}
	else{return(0);}
}

sub hasPolyN {
=head2
=over5
=item hasPolyN
Usage: 		$skipTo = Bio::JParker::ProbeDesign::hasPolyN($seqString)
Function:	Test if the sequence string contains MORE THAN 3 identical 
		bases in a row.
Arguments:	The 5' -> 3' sequence of a DNA probe.
Returns:	Returns the index of the end of the polyN string if true or 
		zero if false.
=back
=cut

	my $seqString = shift;
	
	if ($seqString =~ /(A{4,})/){return (index($seqString, $1) + length($1));}
	elsif ($seqString =~ /(C{4,})/){return (index($seqString, $1) + length($1));}
	elsif ($seqString =~ /(G{4,})/){return (index($seqString, $1) + length($1));}
	elsif ($seqString =~ /(T{4,})/){return (index($seqString, $1) + length($1));}
	else{return(0);}
}

sub reverseComplement {

=head2
=over5
=item ProbeDesign::reverseComplement
Usage:	$reverseSeq = Bio::JParker::ProbeDesign::reverseComplement ($seqString);
Function:	Determines the reverse complement of a DNA sequence.
Arguments:	DNA sequence string.
Returns:	Reverse complement of the DNA sequence string.
=back
=cut

	my $sequence = shift;
	my $rev = reverse($sequence);
	$rev =~ tr/[ATUGCatugc]/[TAACGtaacg]/;
	return($rev);
}

1;
__END__
=head1 NAME

Bio::JParker::ProbeDesign - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Bio::JParker::ProbeDesign;
  blah blah blah

=head1 DESCRIPTION

B<Bio::JParker::ProbeDesign IS NOT part of the BioPerl library.  I have 
written it to install in the same \lib directory because it is a 
biological module.>


=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Jefferson Parker, E<lt>jeffersonparker@apple.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2009 Jefferson Parker, ALL RIGHTS RESERVED

Disclaimer of Warranty.

THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY 
APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT 
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM �AS IS� WITHOUT WARRANTY 
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, 
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM 
IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF 
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

Limitation of Liability.

IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING 
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR 
CONVEYS THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, 
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
ARISING OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT 
NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES 
SUSTAINED BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO 
OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY 
HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

=cut
